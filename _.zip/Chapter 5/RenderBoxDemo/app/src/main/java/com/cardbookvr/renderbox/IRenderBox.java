package com.cardbookvr.renderbox;

/**
 * Created by Schoen and Jonathan on 4/16/2016.
 */
public interface IRenderBox {
    public void setup();
    public void preDraw();
    public void postDraw();
}
