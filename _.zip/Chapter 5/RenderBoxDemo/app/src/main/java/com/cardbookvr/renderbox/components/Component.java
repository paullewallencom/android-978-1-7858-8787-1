package com.cardbookvr.renderbox.components;

import com.cardbookvr.renderbox.Transform;

/**
 * Created by Schoen and Jonathan on 4/16/2016.
 */
public class Component {
    public Transform transform;

    public boolean enabled = true;

}
