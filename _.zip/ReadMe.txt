There are no code files for Chapter 1.

The projects in this book use Cardboard SDK version 0.7. In order to use the Google VR Cardboard Java SDK 0.8 released in May 2016 to execute this book's projects, refer to the article at the following link:

https://www.packtpub.com/sites/default/files/downloads/GoogleVRUpdateGuideforCardbook.pdf

It explains the updates required to the source code of the projects.